package com.pack.two;

import com.pack.one.DemoClass;

public class AccessClass {

	public void show() {
		DemoClass obj = new DemoClass();
		System.out.println(obj.publicAccess);
		//System.out.println(obj.protectedAccess);
		//System.out.println(obj.defaultAccess);
//		System.out.println(privateAcc);
	}
}

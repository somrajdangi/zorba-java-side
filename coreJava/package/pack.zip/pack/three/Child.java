package com.pack.three;

import com.pack.one.ParentClass;

public class Child extends ParentClass{

	public void show() {
		System.out.println(publicAccess);
		System.out.println(protectedAccess);
		//System.out.println(defaultAccess);
		System.out.println();
		
	}
}

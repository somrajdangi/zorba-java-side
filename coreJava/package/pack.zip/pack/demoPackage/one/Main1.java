package com.pack.demoPackage.one;

import com.pack.demoPackage.two.Main2;
import com.pack.demoPackage.two.Main3;
//imports all the class from package
//import com.pack.demoPackage.two.*; 
// for below import it imports only one (static) method from class Main4 
import static com.pack.demoPackage.two.Main4.doWork; 
// It's static import. imports all the data member that are defined as static
//import static java.lang.Math.random;
//import static java.lang.Math.sqrt;
import static java.lang.Math.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;


public class Main1 {

	public static void main(String[] args) throws SQLException {
		Main2 obj = new Main2();
		Main3 obj1 = new Main3();
		//Main4 obj2 = new Main4();
		System.out.println("Hello");
		doWork();
		System.out.println(random());
		System.out.println(sqrt(10.0));
		Connection conn= null;
		Statement stm=conn.createStatement();
		stm.executeBatch();
		// com.sql.
	}

}

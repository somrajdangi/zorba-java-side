package com.pack.demoPackage.two;

public class Main2 {

	public void show() {
		System.out.println("Class Main2 from com.pack.demoPackage.two package");
	}
}

package com.pack.demoPackage.two;

public class Main4 {

	public void showMain() {
		System.out.println("Class Main3 form com.pack.demoPackage.two");
	}
	static {
		System.out.println("Static called from Main4");
	}
	public static void doWork() {
		System.out.println("doWork is static method");
	}
}

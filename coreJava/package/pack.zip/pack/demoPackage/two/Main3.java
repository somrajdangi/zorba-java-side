package com.pack.demoPackage.two;

public class Main3 {

	public void showMain() {
		System.out.println("Class Main3 form com.pack.demoPackage.two");
	}
	
	
}

package com.pack.one;

public class Main1 {

	public static void main(String[] args) {
		DemoClass obj = new DemoClass();
		System.out.println(obj.publicAccess);
		System.out.println(obj.protectedAccess);
		System.out.println(obj.defaultAccess);
			

	}

}

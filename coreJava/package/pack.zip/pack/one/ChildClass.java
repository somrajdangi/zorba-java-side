package com.pack.one;

public class ChildClass extends ParentClass {

	public void show() {
		System.out.println(publicAccess);
		System.out.println(protectedAccess);
		System.out.println(defaultAccess);
//		System.out.println(privateAcc);
	}
}

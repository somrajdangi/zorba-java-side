package com.pack.one;

public class DemoClass {

	public String publicAccess = "I am Public";
	protected String protectedAccess = "I am protected";
	String defaultAccess = "I am Default";
	private String privateAccess = "I am Private";

}

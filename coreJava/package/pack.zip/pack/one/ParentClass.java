package com.pack.one;

public class ParentClass {

	public String publicAccess = "I am Public";
	protected String protectedAccess = "I am protected";
	String defaultAccess = "I am Default";
	private String privateAccess = "I am Private";

}

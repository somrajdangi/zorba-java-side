package com.thread.second;

public class MultiThreaded {

	public static void main(String[] args) {
		A a1 = new A("FIRST"); // a.start();
		A a2 = new A("SECOND");
		A a3 = new A("THIRD");
		A a4 = new A("FOURTH");
		
		System.out.println("thread FIRST "+a1.isAlive());
		System.out.println("thread SECOND "+a2.isAlive());
		System.out.println("thread Third "+a3.isAlive());
		System.out.println("thread FOURTH "+a4.isAlive());
		
		try {
			a1.join();
			a2.join();
			a3.join();
			a4.join();
			
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		System.out.println("thread FIRST after completion :  "+a1.isAlive());
		System.out.println("thread SECOND after completion :  "+a2.isAlive());
		System.out.println("thread Third after completion :  "+a3.isAlive());
		System.out.println("thread FOURTH after completion :  "+a4.isAlive());

		try {
			for (int i = 0; i < 5; i++) {
				System.out.println(Thread.currentThread().getName() + " thread here ************** ");
				Thread.sleep(2500);
				if(i==4)
					System.exit(1);
			}
		} catch (InterruptedException e) {
		}
	}
}

class A extends Thread {
	public A(String tName) {
		super(tName);
		start();
	}

	@Override
	public void run() {
		try {
			for (int i = 0; i < 5; i++) {
				System.out.println(Thread.currentThread().getName() + " thread here : " + i);
				sleep(5000);
			}
		} catch (InterruptedException e) {
		}
		System.out.println(Thread.currentThread().getName() + " ending here ");
	}
}

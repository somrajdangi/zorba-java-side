package com.thread.second;

public class DemoNoInterThreadComunication {

	public static void main(String[] args) {
		
		System.out.println(Thread.currentThread().getName());
		SharedRes res = new SharedRes();
		ThreadRead1 read = new ThreadRead1(res, "READ");
		ThreadWrite1 write = new ThreadWrite1(res, "Write");
		read.setPriority(Thread.MAX_PRIORITY);
		System.out.println(write.getPriority());
//		read.setDaemon(true);
		read.start();
		write.start();
		
	}

}

class SharedRes{
	int data =0;
	synchronized void doWork() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		data=10;
	}
	
	synchronized int show() {
		return data;
	}
}

class ThreadRead1 extends Thread{
	SharedRes res;
	public ThreadRead1(SharedRes res , String tName) {
		super(tName);
		this.res=res;
	}
	
	@Override
	public void run() {
		System.out.println("Reader thread called and data = :"+res.show());
	}
}
class ThreadWrite1 extends Thread{
	SharedRes res;
	public ThreadWrite1(SharedRes res , String tName) {
		super(tName);
		this.res=res;
		
	}
	
	@Override
	public void run() {
		res.doWork();
		System.out.println("Writer thread called ");
	}
}
package com.thread.second;

public class DemoInterThreadComunication {

	public static void main(String[] args) {
		SharedRes2 res = new SharedRes2();
		ThreadRead2 read = new ThreadRead2(res, "READ");
		ThreadWrite2 write = new ThreadWrite2(res, "Write");
		
		read.start();
		write.start();
	}

}

class SharedRes2{
	int data =0;
	synchronized void doWork() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		data=10;
		notify();
	}
	
	synchronized int show() {
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}
}

class ThreadRead2 extends Thread{
	SharedRes2 res;
	public ThreadRead2(SharedRes2 res , String tName) {
		super(tName);
		this.res=res;
	}
	
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()+" started");
		System.out.println("Reader thread called and data = :"+res.show());
	}
}
class ThreadWrite2 extends Thread{
	SharedRes2 res;
	public ThreadWrite2(SharedRes2 res , String tName) {
		super(tName);
		this.res=res;
	}
	
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()+" started");
//		System.out.println("Writer thread called ");
		res.doWork();
		
	}
}
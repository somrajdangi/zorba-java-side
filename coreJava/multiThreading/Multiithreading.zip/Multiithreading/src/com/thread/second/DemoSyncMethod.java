package com.thread.second;

public class DemoSyncMethod {

	public static void main(String[] args) {
		Shared1 sh = new Shared1();
		ThreadA1 a1 = new ThreadA1(sh, "One");
		ThreadA1 a2 = new ThreadA1(sh, "Two");
		a1.start();
		a2.start();

	}

}


class Shared1 {
	
	synchronized void doWork(String tName) {
		System.out.println("Start working on : "+tName);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Ending : "+tName);
	}
}


class ThreadA1 extends Thread {
	Shared1 sh ;
	public ThreadA1(Shared1 sh , String tName) {
		super(tName);
		this.sh=sh;
	}
	@Override
	public void run() {
		sh.doWork(Thread.currentThread().getName());
	}
}
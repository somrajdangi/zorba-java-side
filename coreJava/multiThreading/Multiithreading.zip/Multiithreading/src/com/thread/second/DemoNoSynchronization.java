package com.thread.second;

public class DemoNoSynchronization {

	public static void main(String[] args) {
		Shared sh = new Shared();
		ThreadA a1 = new ThreadA(sh, "One");
		ThreadA a2 = new ThreadA(sh, "Two");
		a1.start();
		a2.start();

	}

}


class Shared {
	
	void doWork(String tName) {
		System.out.println("Start working on : "+tName);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Ending : "+tName);
	}
}


class ThreadA extends Thread {
	Shared sh ;
	public ThreadA(Shared sh , String tName) {
		super(tName);
		this.sh=sh;
	}
	@Override
	public void run() {
		sh.doWork(Thread.currentThread().getName());
	}
}
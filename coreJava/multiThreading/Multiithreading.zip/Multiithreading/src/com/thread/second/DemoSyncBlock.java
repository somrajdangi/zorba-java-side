package com.thread.second;

public class DemoSyncBlock {

	public static void main(String[] args) {
		Shared3 sh = new Shared3();
		ThreadA3 a1 = new ThreadA3(sh, "One");
		ThreadA3 a2 = new ThreadA3(sh, "Two");
		a2.start();
		a1.start();

	}

}

class Shared3 {

	void doWork(String tName) {
		System.out.println("Start working on : " + tName);
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Ending : " + tName);
	}

	void show() {
		System.out.println("Calling show method for : " + Thread.currentThread().getName());
	}
}

class ThreadA3 extends Thread {
	Shared3 sh;

	public ThreadA3(Shared3 sh, String tName) {
		super(tName);
		this.sh = sh;
	}

	@Override
	public void run() {
		synchronized (sh) {
			sh.doWork(Thread.currentThread().getName());
			sh.show();
		}

	}
}
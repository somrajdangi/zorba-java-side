package com.thread.second;

public class DemoSyncMethod2 {

	public static void main(String[] args) {
		Shared2 sh = new Shared2();
		ThreadA2 a1 = new ThreadA2(sh, "One");
		ThreadA2 a2 = new ThreadA2(sh, "Two");
		a1.start();
		a2.start();

	}

}


class Shared2 {
	
	synchronized void doWork(String tName) {
		System.out.println("Start working on : "+tName);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Ending : "+tName);
	}
	
	void show() {
		System.out.println("Calling show method for : "+Thread.currentThread().getName());
	}
}


class ThreadA2 extends Thread {
	Shared2 sh ;
	public ThreadA2(Shared2 sh , String tName) {
		super(tName);
		this.sh=sh;
	}
	@Override
	public void run() {
		sh.doWork(Thread.currentThread().getName());
		sh.show();
	}
}
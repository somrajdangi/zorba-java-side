package com.serial;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Date;

import com.serial.dto.Student;

public class DemoSerialization {

	public static void main(String[] args) throws IOException {
		Student stud = new Student(1, "Mahesh", "Kumar");
		System.out.println(stud);
		
		FileOutputStream fos= new FileOutputStream("Student-data.txt");
		ObjectOutputStream os= new ObjectOutputStream(fos);
		os.writeObject(stud);
		
		os.close();
		fos.close();
		
		Student stud1 = new Student(10, "Ram", "Kumar" , 30 , new Date());
		System.out.println(stud1);
		
		FileOutputStream fos1= new FileOutputStream("Student-data-Ram.txt");
		ObjectOutputStream os1= new ObjectOutputStream(fos1);
		os1.writeObject(stud1);
		
		os1.close();
		fos1.close();
	}

}

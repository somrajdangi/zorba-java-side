package com.serial;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.serial.dto.Student;

public class DemoDeSerialization {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		FileInputStream fis= new FileInputStream("Student-data.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Student s =(Student) ois.readObject();
		System.out.println(s);
		
		ois.close();
		fis.close();
	}

}

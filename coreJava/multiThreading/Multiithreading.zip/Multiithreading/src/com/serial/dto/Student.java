package com.serial.dto;

import java.io.Serializable;
import java.util.Date;

public class Student implements Serializable{

	final static long serialVersionUID =1L;
	
	private int rollNumber;
	private String firstName;
	private static String lastName;
	
	private Date todayDate;
	
	private transient int age; //Not eligible for serialization
	
	public Student(int rollNumber,String firstName,String lastName ) {
		this.rollNumber=rollNumber;
		this.firstName= firstName;
		this.lastName=lastName;
	}
	public Student(int rollNumber,String firstName,String lastName , int age) {
		this.rollNumber=rollNumber;
		this.firstName= firstName;
		this.lastName=lastName;
		this.age=age;
	}
	public Student(int rollNumber,String firstName,String lastName , int age , Date dob) {
		this.rollNumber=rollNumber;
		this.firstName= firstName;
		this.lastName=lastName;
		this.age=age;
		this.todayDate=dob;
	}
	public int getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "Student [rollNumber=" + rollNumber + ", firstName=" + firstName + ", todayDate=" + todayDate + "]";
	}
	
}
// write program to save object in DB.
package com.stream;

import java.util.ArrayList;

public class DemoReduce {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<>();
		al.add("A");
		al.add("C");
		al.add("X");
		al.add("B");
		al.add("D");
		
		System.out.println(al);
		
		System.out.println(al.stream().reduce( String::concat)); // ACXBD
		
		
		

	}

}

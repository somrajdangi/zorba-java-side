package com.stream;

import java.util.Arrays;
import java.util.List;

public class DemoArrays {

	public static void main(String[] args) {
		
		String stringArray[]= new String[5];
		stringArray[0]= "A" ;
		stringArray[1]= "B" ;
		stringArray[2]= "C" ;
		stringArray[3]= "D" ;
		stringArray[4]= "E" ;
		
		List<String> list = Arrays.asList(stringArray);
		System.out.println(list);
		
		List<Object> list1 = Arrays.asList("Hello", 10 , 10.01f , false);
		System.out.println(list1);

	}

}

package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.dto.Student;

public class DemoOptional {

	public static void main(String[] args) {
		ArrayList<Student> studList = new ArrayList<>();
		Student stud1 = new Student(1, "SOM");
		Student stud2 = new Student(2, "Anil");
		Student stud3 = new Student(3, "Mahesh Kumar");
		Student stud4 = new Student(4, "Rulesh");
		
		studList.add(stud1);
		studList.add(stud2);
		studList.add(stud3);
		studList.add(stud4);
		System.out.println(studList);
		
		Student stu  =studList.stream().filter(stud -> stud.getName().length() > 5)
		.collect(Collectors.toList()).get(0);
		
		System.out.println(stu);
		
		Optional<Student> optional  =studList.stream().filter(stud -> stud.getName().length() > 5)
				//.findFirst();
				.findAny();
		Student student1 = optional.isPresent() ? optional.get() : null;
		System.out.println(student1);
		
		Student student2 = studList.stream().filter(stud -> stud.getName().startsWith("B"))
				.findFirst().orElse(null);
		
		System.out.println(student2);
		if(student2 == null)
			throw new RuntimeException("No Match found");
		
		
		Student student3 = studList.stream().filter(stud -> stud.getName().startsWith("X"))
				.findFirst().orElseThrow(() -> new RuntimeException("No Match found"));
		
		System.out.println(student3);

	}

}

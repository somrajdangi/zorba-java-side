package com.stream;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class DemoGroup {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("A", "A", "B", "D", "Y");
		System.out.println(list.stream().filter(x -> !x.equals("A"))
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting())));
	}
}

// Find list of employees grouping based on length of name > 3 
// and name starts with A
// Date, LocalTime , LocalDateTime
// Calendar 
// StringTokenizer
// Serialization/De-serialization 
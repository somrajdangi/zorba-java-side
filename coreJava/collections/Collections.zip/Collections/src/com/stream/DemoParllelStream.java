package com.stream;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class DemoParllelStream {

	public static void main(String[] args) {
		System.out.println("Start Adding integer into list "+LocalDateTime.now());
		ArrayList<Integer> list = new ArrayList<>();
		for (int i =0 ; i< 10000000 ; i++) {
			list.add(i);
		}
		System.out.println(list.size());

		System.out.println("Starting using streams "+LocalDateTime.now());
		
		list.stream().filter(num -> num%2 ==0).collect(Collectors.toList());
		System.out.println("After using streams "+LocalDateTime.now());
		
		//System.out.println("Starting using  streams "+LocalDateTime.now());
		
		list.parallelStream().filter(num -> num%2 ==0).collect(Collectors.toList());
		System.out.println("After using parallelStream "+LocalDateTime.now());
		
	}

}

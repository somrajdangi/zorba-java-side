package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DemoStream1 {

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		list.add(100);
		list.add(200);
		list.add(500);
		list.add(300);
		System.out.println(" Original List "+list);

		ArrayList<Integer> list1 = new ArrayList<>();
		
		for(Integer i : list) {
			i= i+10;
			list1.add(i);
		}
		System.out.println(" After for loop List "+list1);

		List<Integer> newList =list.stream().map(x  -> x + 10).collect(Collectors.toList());
		
		List<Integer> newList1 =list.stream().map(x  -> doMultiplication(x)).collect(Collectors.toList());
		System.out.println("Using Lambda "+newList);
		System.out.println("Using Lambda "+newList1);
		System.out.println(" Original List at last "+list);
	}
	
	public static int doMultiplication(int i) {
		System.out.println("input form lambda is :"+i);
		return i*i;
	}

}

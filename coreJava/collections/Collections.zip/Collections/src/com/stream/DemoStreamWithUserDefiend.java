package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import com.dto.Student;

public class DemoStreamWithUserDefiend {

	public static void main(String[] args) {
		ArrayList<Student> studList = new ArrayList<>();
		Student stud1 = new Student(1, "SOM");
		Student stud2 = new Student(2, "Anil");
		Student stud3 = new Student(3, "Mahesh");
		Student stud4 = new Student(4, "Rulesh");
		
		studList.add(stud1);
		studList.add(stud2);
		studList.add(stud3);
		studList.add(stud4);
		studList.add(stud4);
		System.out.println(studList);
		
		System.out.println(studList.stream().count());
		System.out.println(studList.stream().distinct().collect(Collectors.toList()));
		
		System.out.println(studList.stream().filter(studObj -> studObj.getName().endsWith("h"))
			.collect(Collectors.toList()));
		
		System.out.println(studList.stream().map(studObj -> appendName(studObj))
		.collect(Collectors.toList()));
	}
	
	
	public static Student appendName(Student st) {
		st.setName(st.getName()+" Kumar");
		return st;
	}
	
	

}

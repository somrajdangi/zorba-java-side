package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

public class DemoStream2 {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
		list.add("Java");
		list.add("C");
		list.add("C++");
		list.add("C#");
		list.add("PHP");
		list.add("Go Lang");
		list.add("Phython");
		
		System.out.println(" Original List "+list);
		// older way
		ArrayList<String> list1 = new ArrayList<>();
		for(String str : list) {
			if(str.length() > 3)
				list1.add(str);
		}
		System.out.println(" After for loop List "+list1);
		// using Lambda
		List<String> newList = list.stream().filter(str -> str.length() > 3)
				.collect(Collectors.toList());
		
	/*	Vector<String> newVector =(Vector<String>) list.stream().filter(str -> str.length() > 3)
				.collect(Collectors.toCollection(Vector :: new));*/
	
		System.out.println("Using Lambda "+newList);
		System.out.println(" Original List at last "+list);
	}
	
	

}

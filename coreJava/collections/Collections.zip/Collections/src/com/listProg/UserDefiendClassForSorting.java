package com.listProg;

import java.util.ArrayList;
import java.util.Collections;

import com.dto.College;
import com.dto.Student;

public class UserDefiendClassForSorting {

	public static void main(String[] args) {
		ArrayList<College> list = new ArrayList<>();
		College c1 = new College(1, "BOSTON");
		College c2 = new College(2, "IIT");
		College c3 = new College(3, "IIM");
		
		list.add(c2);
		list.add(c1);
		list.add(c3);
		System.out.println(list);
		

		Student stud1 = new Student(1, "SOM");
		Student stud2 = new Student(2, "Anil");
		Student stud3 = new Student(3, "Mahesh");
		Student stud4 = new Student(4, "Rulesh");
		
		ArrayList<Student> studList = new ArrayList<>();
		studList.add(stud1);
		studList.add(stud2);
		studList.add(stud2);
		studList.add(stud3);
		
		System.out.println("Before sorting "+studList);
		
		Collections.sort(studList);
		
		System.out.println("After sorting "+studList);

	}

}
/*
// Write a prog to sort the list of student based on 
   	name in ascending 
    age as desc.
// same in set 
   Make use of Iterator to iterate Set.
 * 
 */

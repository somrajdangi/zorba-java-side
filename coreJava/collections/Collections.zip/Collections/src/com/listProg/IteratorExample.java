package com.listProg;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorExample {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<>();
		al.add("A");
		al.add("B");
		al.add("F");
		al.add("D");
		al.add("C");
		al.add("H");
		al.add("I");
		System.out.println(al.size());
		System.out.println(al);
		
		Iterator<String> itr= al.iterator();
		while(itr.hasNext()) {
			String element = itr.next();
			System.out.println(element);
		}
		
		
		

	}

}

package com.listProg;

import java.util.ArrayList;
import java.util.Collections;

public class SortingOnList {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
		list.add("A");
		list.add("X");
		list.add("G");
		list.add("M");
		list.add("A");
		list.add("N");
		
		System.out.println(list);
		// sorting on list for pre-defiend classes
		Collections.sort(list);
		System.out.println("AFter Sorting");
		System.out.println(list);

	}

}

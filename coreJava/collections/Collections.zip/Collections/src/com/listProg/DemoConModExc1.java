package com.listProg;

import java.util.ArrayList;
import java.util.Iterator;

public class DemoConModExc1 {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<>();
		al.add("A");
		al.add("B");
		al.add("F");
		al.add("D");
		al.add("C");
		al.add("H");

		// System.out.println(al.get(6));

		Iterator<String> itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(al);
			String element = itr.next();
			if (element.equals("F")) {
				// al.remove("F"); // throws an exception
				itr.remove(); // uses iterator remove method
			}
			System.out.println(element);
		}

	}

}

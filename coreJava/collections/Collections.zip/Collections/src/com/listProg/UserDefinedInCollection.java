package com.listProg;

import java.util.ArrayList;

import com.dto.Student;

public class UserDefinedInCollection {

	public static void main(String[] args) {
		ArrayList<Student> studList = new ArrayList<>();
		Student stud1 = new Student(1, "SOM");
		Student stud2 = new Student(2, "Anil");
		Student stud3 = new Student(3, "Mahesh");
		Student stud4 = new Student(4, "Rulesh");
		
		studList.add(stud1);
		studList.add(stud2);
		studList.add(stud3);
		studList.add(stud4);
		System.out.println(studList);
		for(Student st : studList) {
			System.out.println(st.pritValue());
		}
		
	}

}


package com.listProg;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class DemoThreadCollection {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<>();
		al.add("A");
		al.add("A");
		al.add("A");
		al.add("A");
		
		Vector<String> v = new Vector<>();
		v.add("A");
		v.add("A");
		
		Read read1 = new Read(v);
		Write write1 = new Write(v);
		read1.start();
		write1.start();
		
		
		System.out.println(v);
		/*Read read = new Read(al);
		Write write = new Write(al);
		read.start();
		write.start();*/
		
		

	}

}
class Read extends Thread{
	Vector<String > al;
	public Read(Vector<String > al  ){
		this.al=al;
	}
	@Override
	public void run() {
		/*for(String str : al) {
			System.out.println("In Read thread "+str);
		}*/
		Iterator<String> itr = al.iterator();
		while(itr.hasNext()) {
			String st = itr.next();
			System.out.println("In Read thread "+st);
		}
		
	}
}
class Write extends Thread{
	Vector<String > al;
	public Write(Vector<String > al  ){
		this.al=al;
	}
	@Override
	public void run() {
		/*for(String str : al) {
			System.out.println("In Write thread "+str);
			al.add("JAVA");
		}*/
		Iterator<String> itr = al.iterator();
		while(itr.hasNext()) {
			String st = itr.next();
			itr.remove();
			System.out.println("In Write thread "+st);
		}
		
	}
}
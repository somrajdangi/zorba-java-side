package com.listProg;

import java.util.LinkedList;

public class DemoLinkedList {

	public static void main(String[] args) {
		LinkedList<String> ll = new LinkedList<>();
		ll.add("A");
		ll.add("B");
		ll.add("A");
		ll.add("C");
		
		System.out.println(ll);
		
	}

}

package com.listProg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Vector;

public class DemoVector {

	public static void main(String[] args) {
		Vector<Number> v= new Vector<>();
		v.add(10.01);
		v.add(1);
		v.add(0);
		
		System.out.println(v);
		
		ArrayList<String> al = new ArrayList<>();
		al.add("A");
		al.add("A");
		al.add("A");
		
//		Collections.synchronizedList(al); // way to make collection thread safe.

	}

}

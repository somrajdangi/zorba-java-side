package com.mapType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class DemoHashMap {

	public static void main(String[] args) {
		HashMap<Integer, String> map = new HashMap<>();
		map.put(1, "One");
		map.put(2, "Two");
		map.put(12, "Four");
		map.put(3, "Three");
		
		map.put(10, "One");
		map.put(20, "Two");
		map.put(11, "Four");
		map.put(13, "Three");
		
		map.put(21, "One");
		map.put(22, "Two");
		map.put(31, "Four");
		map.put(43, "Three");
		map.put(41, "One");
		map.put(42, "Two");
		map.put(51, "Four");
		map.put(53, "Three");
		map.put(null, "NULL");
		map.put(1, "JAVA");
		map.put(null, "NULL value");
		
		System.out.println(map.size());
		System.out.println(map);
		//read from map
		System.out.println(map.get(1));
		map.remove(1);
		
		// Iterate using for each loop
		for(Map.Entry<Integer, String> entry :  map.entrySet()) {
			Integer key = entry.getKey();
			String value= entry.getValue();
			System.out.println("Key = "+key +" , Value = "+value);
		}
		
		System.out.println("************ Using Iterator **********");
		Iterator<Integer> mapItr= map.keySet().iterator();
		while(mapItr.hasNext()) {
			Integer key =mapItr.next();
			String value= map.get(key);
			System.out.println("Key = "+key +" , Value = "+value);
		}

	}

}

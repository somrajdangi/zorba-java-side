package com.mapType;

import java.util.TreeMap;

import com.dto.Patient;

public class DemoTreeMap {
	
	public static void main(String[] args) {
		TreeMap<String, String> tMap = new TreeMap<>();
		tMap.put("A", "A");
		tMap.put("A", "AA");
		tMap.put("Z", "ZZ");
		tMap.put("B", "BB");
		//tMap.put(null, "NULL");
		
		System.out.println(tMap.size());
		System.out.println(tMap);
		
		
		TreeMap<Patient, String> pMap = new TreeMap<>();
		Patient p1= new Patient(1, "Patient 1");
		Patient p2= new Patient(2, "Patient 2");
		Patient p3= new Patient(1, "Patient 1");
		
		pMap.put(p1, "One");
		pMap.put(p3, "Three");
		
		System.out.println(pMap.size());
		
		
	}
}

package com.mapType;

import java.util.HashMap;

import com.dto.Student;

public class UserDefiendObjInMap {

	public static void main(String[] args) {
		HashMap<Student	, Student> map = new HashMap<>();
		Student stud1 = new Student(1, "SOM"); // 123
		Student stud2 = new Student(2, "Anil");
		
		Student stud3 = new Student(1, "SOM"); // 456
		
//		Student stud4 = new Student(4, "Rulesh");
		
		map.put(stud2, stud2);
		map.put(stud1, stud1);
		map.put(stud3, stud3);
		
		System.out.println(map.size()); //2
//		map.put(stud4, stud4);
		
		System.out.println(map);
		

	}

}

package com.setType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeSet;

import com.dto.College;
import com.dto.Student;

public class UserDefiendElementInSet2 {

	public static void main(String[] args) {
		HashSet<College> collegeSet = new HashSet<>();
		
		College c1 = new College(1, "IIT"); // 123
		College c2 = new College(2, "MIT"); // 345
		College c3 = new College(2, "MIT"); // 456
		
		collegeSet.add(c1);
		collegeSet.add(c2);
		collegeSet.add(c3);
		
		System.out.println(collegeSet.size()); 
		System.out.println(collegeSet);
		
		
		HashSet<Student> studentSet = new HashSet<>();
		
		Student stud1 = new Student(1, "SOM");
		Student stud2 = new Student(2, "Anil");
		Student stud3 = new Student(2, "Omi");
		
		studentSet.add(stud1);
		studentSet.add(stud2);
		studentSet.add(stud3);
		
		System.out.println(studentSet.size()); 
		
		HashMap<Student, Object> map = new HashMap<>();
		map.put(stud1, null);
		map.put(stud2, null);
		map.put(stud3, null);
		
		
		System.out.println(map.size());
		
		
	}

}
//public int compareTo(Student o) { -1 , 0 , 1
//	return this.getName().compareTo(o.getName());
//}

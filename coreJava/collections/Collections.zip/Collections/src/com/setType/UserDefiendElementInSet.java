package com.setType;

import java.util.TreeSet;

import com.dto.Student;

public class UserDefiendElementInSet {

	public static void main(String[] args) {
		TreeSet<Student> studentSet = new TreeSet<>();
		
		Student stud1 = new Student(1, "SOM");
		Student stud2 = new Student(2, "Anil");
		Student stud3 = new Student(3, "Mahesh");
		Student stud4 = new Student(4, "Rulesh");
		
		studentSet.add(stud1);
		studentSet.add(stud2);
		studentSet.add(stud3);
		studentSet.add(stud4);
		
		System.out.println("SIze = "+studentSet.size());
		
		System.out.println(studentSet);
		
	}

}
//public int compareTo(Student o) { -1 , 0 , 1
//	return this.getName().compareTo(o.getName());
//}

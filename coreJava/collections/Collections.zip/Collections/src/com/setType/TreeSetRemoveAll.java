package com.setType;

import java.util.TreeSet;

public class TreeSetRemoveAll {

	public static void main(String[] args) {
		TreeSet<String> tSet = new TreeSet<>();
		tSet.add("A");
		tSet.add("a");
		tSet.add("X");
		tSet.add("T");
		tSet.add("A");
		
		System.out.println("tSet size = "+tSet.size()); 
		System.out.println(tSet);
		
		
		TreeSet<String> tSet1 = new TreeSet<>();
		tSet1.add("A");
		tSet1.add("B");
		tSet1.add("C");
		
		System.out.println("Before Remove all tSet1  = "+tSet1); 
		
		tSet.removeAll(tSet1);
		
		System.out.println("Before Remove all tSet1  = "+tSet1); 
		
		System.out.println("After Remove all tSet size = "+tSet.size()); 
		System.out.println(tSet);
		
		System.out.println("***********************************");
		String s1=null; 
		//s1.compareTo("");
//		tSet1=null;
		//tSet1.add(s1); NPE
		System.out.println(tSet1);

	}

}

// 1 4 6 9 2 3
// 

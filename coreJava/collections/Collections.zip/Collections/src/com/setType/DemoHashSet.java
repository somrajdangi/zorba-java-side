package com.setType;

import java.util.Collections;
import java.util.HashSet;

import com.dto.College;

public class DemoHashSet {

	public static void main(String[] args) {
		HashSet<String> set1 = new HashSet<>();
		set1.add("A");
		set1.add("P");
		set1.add("N");
		set1.add("A");
		set1.add("B");
		
		System.out.println(set1.size());
		System.out.println(set1);
		
		
		College c1 = new College(1, "BOSTON");
		College c2 = new College(2, "IIT");
		College c3 = new College(3, "IIM");
		
		HashSet<College> set2 = new HashSet<>();
		set2.add(c3);
		set2.add(c1);
		set2.add(c2);
		set2.add(c2);
		
		System.out.println(set2.size());
		System.out.println(set2);
		
		
		

	}

}

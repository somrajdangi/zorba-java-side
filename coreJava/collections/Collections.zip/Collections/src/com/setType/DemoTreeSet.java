package com.setType;

import java.util.TreeSet;

public class DemoTreeSet {

	public static void main(String[] args) {
		TreeSet<String> tSet = new TreeSet<>();
		tSet.add("A");
		tSet.add("a");
		tSet.add("X");
		tSet.add("T");
		tSet.add("A");
		System.out.println("tSet size = "+tSet.size()); // 4 as no duplicates are allowed
		System.out.println(tSet);
		
		//tSet.remove("A");
		//System.out.println(tSet);
		
		for(String str : tSet) {
			System.out.println(str);
		}
		// Adding two sets (addAll() )
		TreeSet<String> tSet1 = new TreeSet<>();
		tSet1.add("A");
		tSet1.add("B");
		tSet1.add("C");
		tSet1.add("D");
		System.out.println("tSet1 size = "+tSet1.size());
		System.out.println(tSet1);
		
		tSet.addAll(tSet1);
		
		System.out.println("After adding all tSet size = "+tSet.size()); 
		System.out.println(tSet);
		
		
		

	}

}

package com.lambdaType;

import java.util.ArrayList;
import java.util.HashMap;

public class DemoForEach {

	public static void main(String[] args) {
		ArrayList<String> stringList = new ArrayList();

		stringList.add("A");
		stringList.add("Z");
		stringList.add("B");
		stringList.add("A");
		stringList.add("1");
		stringList.add("AA");

		stringList.forEach((x) -> {
			System.out.println(x);
		});

		HashMap<Integer, String> map = new HashMap<>();
		map.put(1, "One");
		map.put(2, "Two");
		map.put(12, "Four");
		map.put(3, "Three");
		
//		map.remove(3);

		map.forEach((k, v) -> {
			System.out.println("Key is :" + k );
			System.out.println( "value is : " + v);
			if(v=="Two")
//				break;
				return;
		});
	}

}

// iterate on set using forEach
// Use forEach to iterate over empty collection.

package com.lambdaType;

import java.util.ArrayList;
import java.util.Comparator;

import com.dto.College;

public class DemoListSortMethod {

	public static void main(String[] args) {
		ArrayList<College> list = new ArrayList<>();
		College c1 = new College(1, "BOSTON");
		College c2 = new College(3, "IIT");
		College c3 = new College(2, "IIM");
		list.add(c2);
		list.add(c1);
		list.add(c3);
		System.out.println(list);
		
		Comparator<College> comparatorName = (college1 , college2 ) -> {
			return college1.getName().compareTo(college2.getName());
		};
		
		list.sort(comparatorName);
		System.out.println(list);
		
		list.sort( (col1 , col2) ->   col1.getName().compareTo(col2.getName()));
	}

}

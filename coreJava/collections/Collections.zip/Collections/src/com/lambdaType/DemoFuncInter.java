package com.lambdaType;

import com.dto.FunctionalInteface;
import com.dto.FunctionalInteface2;

public class DemoFuncInter {

	public static void main(String[] args) {
		// legacy way. Using anonymous class
		FunctionalInteface obj =new FunctionalInteface() {
			
			@Override
			public void doWork() {
				System.out.println("Do Work");
			}
		};
		obj.doWork();
		
		// using lambda
		FunctionalInteface obj1= () -> {
			System.out.println("Lambda called");
		};
		obj1.doWork();
		
		FunctionalInteface2 obj2= (x , y) -> {
			System.out.println("Lambda called for parameter "+x);
		};
		obj2.doWork(10 , 20);
	}

}


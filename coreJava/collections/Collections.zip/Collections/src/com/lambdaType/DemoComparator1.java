package com.lambdaType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.dto.College;

public class DemoComparator1 {

	public static void main(String[] args) {
		ArrayList<College> list = new ArrayList<>();
		College c1 = new College(1, "BOSTON");
		College c2 = new College(3, "IIT");
		College c3 = new College(2, "IIM");
		list.add(c2);
		list.add(c1);
		list.add(c3);
		System.out.println(list);
		Comparator<College>  comparatorId = new Comparator<College>() {
			@Override
			public int compare(College obj1, College obj2) {
				return Integer.compare(obj1.getId(), obj2.getId());
			}
		};
		
		System.out.println("After sorting");
		Collections.sort(list , comparatorId);
		System.out.println(list);
		
		// using lambda
		Comparator<College> comparatorName = (college1 , college2 ) -> {
			return college1.getName().compareTo(college2.getName());
		};
		Collections.sort(list , comparatorName);
		System.out.println("AFter sorting by name");
		System.out.println(list);
		
	}

}

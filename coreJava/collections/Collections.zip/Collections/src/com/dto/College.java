package com.dto;

public class College {

	private int id;
	private String name;
	private String state;
	public College(int id ,String name) {
		this.id=id;
		this.name=name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int hashCode() {
		int code = super.hashCode();
		System.out.println("HASHCODE "+ id);
		return id;
	}

	@Override
	public boolean equals(Object obj) {
		College c= (College) obj;
		
		//Integer objId=id;
		boolean flag = this.id==c.id;
		System.out.println("Equals "+flag);
		return flag ;
	}
	
	@Override
	public String toString() {
		return "College [id=" + id + ", name=" + name + "]";
	}

}

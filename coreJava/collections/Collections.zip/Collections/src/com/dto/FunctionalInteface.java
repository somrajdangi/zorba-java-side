package com.dto;

@FunctionalInterface
public interface FunctionalInteface {
	void doWork();
	static void init() {
		
	}
	default void methodDefault() {
		
	}
}

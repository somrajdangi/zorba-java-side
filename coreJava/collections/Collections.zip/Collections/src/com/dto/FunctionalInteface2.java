package com.dto;


public interface FunctionalInteface2 {

	void doWork(int i , int j);
}

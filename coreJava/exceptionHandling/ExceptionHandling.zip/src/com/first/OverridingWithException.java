package com.first;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

public class OverridingWithException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
class Parent {
	void readFile() throws IOException {
		FileInputStream fis = new FileInputStream("");
	}
}
class Child extends Parent {
	
	/*public void demo() throws IOException {
		super.readFile();
	}*/
	
	@Override
	public void readFile() throws FileNotFoundException{
		System.out.println("Overriding in child class");
	}
	/*@Override
	public void readFile() throws Exception{ // broader -> parrent_exception type
		System.out.println("Overriding in child class");
	}*/
	/*@Override
	public void readFile() throws SQLException{ // new exception 
		System.out.println("Overriding in child class");
	}*/
}
package com.first;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class DemoCheckedExcep {

	public static void main(String[] args) throws FileNotFoundException {
		File file= new File("temp");
		FileInputStream fis = new FileInputStream(file);
		
	}
}

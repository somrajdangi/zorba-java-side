package com.first;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class DemoTryMultiCatch {

	public static void main(String[] args) {
		try {
			int i = 10 / 0; // ArithmeticException
			FileInputStream fis = new FileInputStream(""); // FileNotFoundException
			fis.read(); // IOException
			System.out.println("Last line of Try");
		} catch (FileNotFoundException e) {
			// do Work A
			System.out.println("do Work A");
		} catch (ArithmeticException e) {
			// do Work B
			System.out.println("do Work B");
		} catch (IOException e) {
			// do Work C
			System.out.println("do Work C");
		} 
		System.out.println("******************************");
		try {
			int i = 10 / 0; // ArithmeticException
			FileInputStream fis = new FileInputStream(""); // FileNotFoundException
			fis.read(); // IOException
		//} catch (FileNotFoundException | IOException | ArithmeticException e) { // error as use only super type exception
		} catch (IOException | ArithmeticException e) {
			// do generic work
			System.out.println("Catch for all exception");
		}
		

	}

}

package com.first;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class NestedTryCatch {

	public static void main(String[] args) {
		try { // nested try catch
			FileInputStream fis = new FileInputStream("");
			try {
				fis.read();
			} catch (IOException e) {
				
			}
			System.out.println("last line of try block");
			
		} catch (FileNotFoundException e) {
			
		}

	}

}

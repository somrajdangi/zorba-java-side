package com.first;

public class DemoThrow3 {
	public static void main(String[] args) {
		DemoThrow3 obj =null;
		try {
			obj.show();
			checkVoterEligibility(20);
		} catch (UnderAgeException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			System.out.println("Not allowed to vote.");
		}
	}
	static void checkVoterEligibility(int age) {
		if (age < 18 )
		{
			throw new UnderAgeException("Under Age as age is : "+age);
		} else {
			System.out.println("Eligiable to vote");
		}
	}
	
	public void show() {
		System.out.println("Demo throw 2 class");
	}
}
class UnderAgeException extends RuntimeException{ // user defined exception
	public UnderAgeException(String message) {
		super(message); // calls the immediate parent class constructor 
	}
}
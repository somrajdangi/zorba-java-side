package com.first;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class DemoNestedTry1 {

	public static void main(String[] args) {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream("D:\\ZORBA\\1015-\\WS\\Exceptions\\src\\com\\first\\DemoNestedTry1.java");
			int k= 10/0;
			try {
				int i = 10 / 0;
			} catch (ArithmeticException e) {
				System.out.println("ArithmeticException occured");
			}
			System.out.println(fis.read());
		} catch (FileNotFoundException e) {
			System.out.println("IOException occured");
		} catch (IOException e) {
			System.out.println("IOException ");
		} finally {

			try {
				if (fis != null)
					fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

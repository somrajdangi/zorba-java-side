package com.first;

public class DemoFinally {

	public static void main(String[] args) {
		try {
			int a = 10;
			int b = (int) (Math.random() * 5);
			System.out.println("Value of b is :" + b);
			int div = a / b;
			System.out.println("Value of div " + div);
			
		} catch (ArithmeticException e) {
			System.out.println("Exception occured "+e.getMessage());
		} finally {
			System.out.println("Division operation completed");
		}

	}

}

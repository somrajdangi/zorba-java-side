package com.first;

public class DemoThrow {

	public static void main(String[] args) throws Exception {
		System.out.println("Hello Throw example");

		System.out.println();
		throw new Exception();
	}

}

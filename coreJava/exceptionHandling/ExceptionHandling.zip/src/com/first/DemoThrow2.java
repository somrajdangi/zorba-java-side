package com.first;

public class DemoThrow2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DemoThrow2 obj =null;
		try {
			obj.show();
			checkVoterEligibility(20);
		} catch (RuntimeException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			System.out.println("Not allowed to vote.");
		}
		
	}
	
	public void show() {
		System.out.println("Demo throw 2 class");
	}
	
	 static void checkVoterEligibility(int age) {
		if (age < 18 )
		{
			//System.out.println("Under Age");
			throw new RuntimeException("Under Age");
		} else {
			System.out.println("Eligiable to vote");
		}
	}

}

package com.first;

public class DemoFirstException {

	public static void main(String[] args) {
		int a = 10;
		int b = (int) (Math.random() * 5);
		System.out.println("Value of b is :" + b);
		try {
			int div = a / b;
			System.out.println("Value of div " + div);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("End of program");
		// Exception e ;

	}

}

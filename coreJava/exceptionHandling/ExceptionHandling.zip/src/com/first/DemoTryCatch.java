package com.first;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class DemoTryCatch {

	public static void main(String[] args) {
		try {
			//FileInputStream fis = new FileInputStream("temp");
			System.out.println("No Exception");
		} catch (FileNotFoundException e) {
			// No exception generated in try block
			// so catch block will not be executed ever.
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

		int a = 10;
		int b = 10;// (int) (Math.random() * 5);
		int div = 0;
		System.out.println("Value of b is :" + b);
		try {
			// div = a / b;
			System.out.println("Value of div " + div);
		} catch (ArithmeticException e) {
			e.printStackTrace();
		}

		System.out.println("End of program");
	}
}

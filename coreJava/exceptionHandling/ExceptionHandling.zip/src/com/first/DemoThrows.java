package com.first;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class DemoThrows {
	
	public DemoThrows() {
		int a =10/0; 
	}

	public static void main(String[] args) {
		try {
			//readFile();
			doWork(); // 1
		}catch (Exception e) { 
			System.out.println("catch block");
			e.printStackTrace();
		}

	}
	
	public static void doWork() throws Exception { // 2
		readFile(); //3
	}
	
	public static void readFile() throws FileNotFoundException , Exception{ //4
		FileInputStream fis = new FileInputStream(""); //5
	}
	

	public void show() throws ArithmeticException{ // not correct as throws must be used only for checked exception
		
	}
}
/*
public FileInputStream(String name)  {
    try{
    this(name != null ? new File(name) : null);
    } catch(Excep e){
    	SYSOUT("excep");
    }
}



*/
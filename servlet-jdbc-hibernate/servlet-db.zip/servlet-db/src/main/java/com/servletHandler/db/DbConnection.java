package com.servletHandler.db;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.servletHandler.dto.User;

public class DbConnection {
	private final static String url ;
	private  final static  String username ;
	private  final static  String password ;
	private  final static  String driver ;
	
	// read data form properties file
	static {
		url ="jdbc:oracle:thin:@172.16.100.57:1521:XE";
		username="scorg";
		password ="scorg_qa";
		driver ="oracle.jdbc.OracleDriver";
	}
	
	public static Connection getConnection(){
		Connection conn=null;
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	public static void persistData(User user) throws SQLException {
		Connection conn = DbConnection.getConnection();
		String sql ="insert into USER_REGISTER (user_name , user_email ,user_password ) "
				+ " values (?,?,?)";
		PreparedStatement pst= conn.prepareStatement(sql);
		pst.setString(1, user.getUserName());
		pst.setString(2, user.getUserEmail());
		pst.setString(3, user.getUserPassword());
		
		pst.executeUpdate();
	}
	

}

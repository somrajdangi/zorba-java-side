package com.servletHandler;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servletHandler.db.DbConnection;

import oracle.jdbc.driver.DBConversion;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("canName");
		String email = request.getParameter("canEmail");
		String password = request.getParameter("canPassword");
		
		Connection conn =null;
		
		try {
//			Class.forName("oracle.jdbc.OracleDriver");
//			Connection conn =DriverManager.getConnection("jdbc:oracle:thin:@172.16.100.57:1521:XE", "scorg", "scorg_qa");
			
			conn = DbConnection.getConnection();
			String sql ="insert into USER_REGISTER (user_name , user_email ,user_password ) "
					+ " values (?,?,?)";
			PreparedStatement pst= conn.prepareStatement(sql);
			pst.setString(1, name);
			pst.setString(2, email);
			pst.setString(3, password);
			
			pst.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		
		
		
	}

}
/*
spring.datasource.url = jdbc:oracle:thin:@172.16.100.57:1521:XE
spring.datasource.username = scorg
spring.datasource.password = scorg_qa*/

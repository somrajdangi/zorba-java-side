package com.example.second;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DemoSendRedirect
 */
@WebServlet("/reqDispatcher2")
public class DemoRequestDispatcher2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String canName =request.getParameter("canName");
		String canEmail =request.getParameter("canEmail");
		System.out.println(canName +"  "+canEmail);
		//response.getWriter().append("Value entered on html was :- "+canName+" & "+canEmail);
		RequestDispatcher rd = request.getRequestDispatcher("img/download.jpg");
		rd.include(request, response);
		
		//response.getWriter().append("Value entered on html was :- "+canName+" & "+canEmail);
	}

}

package com.example.first;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DemoSendRedirect
 */
public class DemoSendRedirect extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DemoSendRedirect() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String canName =request.getParameter("canName");
		String canEmail =request.getParameter("canEmail");
		System.out.println(canName +"  "+canEmail);
		
		response.sendRedirect("DemoSendRedirect2");
		//response.sendRedirect("comfirmation.html");
		//response.getWriter().append("Served at: "+ canName +" ").append(request.getContextPath());
	}

}
